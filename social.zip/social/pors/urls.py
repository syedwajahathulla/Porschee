from django.contrib import admin
from django.urls import path
from django.conf.urls import include
from .views import *
from .import views


urlpatterns = [
    path('', views.home, name="home"),
    path('home/', views.home, name="home"),
    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('explore/', views.exploreView.as_view(), name="explore"),
    path('upload/', views.upload, name="upload"),
    path('stories/', views.stories, name="stories"),
    path('profile/', views.profile, name="profile"),
    path('editprofile/', views.editprofile, name="editprofile"),
    path('account_setting/', views.account_setting, name="account_setting"),
    path('profile_checkout/<str:pk>/', views.profile_checkout, name="profile_checkout"),
    path('search/', views.search, name="search"),
    path('chat/', views.chat, name="chat"),
    path('notifications/', views.notifications, name="notifications"),
    path('followers/', views.followers, name="followers"),

    path('send-friend-req/', views.send_friend_req, name="send-friend-req"),   
    path('del-friend-req/', views.del_friend_req, name="del-friend-req"), 
    path('accept-request/', views.accept_invatation, name="accept-request"),
    path('reject-request/', views.reject_invitation, name="reject-request"), 

    path('like-unlike-post/', views.like_unlike_post, name="like-unlike-post"),
    path('delet-post/', views.my_post_delet, name="delet-post"),  
]

