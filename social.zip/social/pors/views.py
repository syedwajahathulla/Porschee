from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q
from django.views.generic.list import ListView
from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
# Create your views here.
from .models import *
from .forms import *
from .decorators import unauthenticated_user, allowed_users
#
from django.views.generic.edit import UpdateView, CreateView, DeleteView
#
from django.contrib.auth.models import User
from itertools import chain


def registerPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(
                    request, 'Account was succesfully created for ' + user)

                return redirect('login')

        context = {'form': form}
        return render(request, 'accounts/register.html', context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'accounts/login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
def home(request):
    # List of profiles to follow:
    me = request.user
    myprofiles = Myprofile.objects.all().exclude(user=me)
    # add story (form)
    story_form = StoryForm()
    profile = Myprofile.objects.get(user=request.user)
    if request.method == 'POST':
        story_form = StoryForm(request.POST or None, request.FILES or None)
        if story_form.is_valid():
            instance = story_form.save(commit=False)
            instance.uploaded_by = profile
            instance.save()
            story_form.save()

    # follow & unfollow funcionality
    user = User.objects.get(username__iexact=request.user)
    profile = Myprofile.objects.get(user=user)
    rel_r = FollowUser.objects.filter(sender=profile)
    rel_s = FollowUser.objects.filter(receiver=profile)
    rel_receiver = []
    rel_sender = []
    for item in rel_r:
        rel_receiver.append(item.receiver.user)
    for item in rel_s:
        rel_receiver.append(item.sender.user)

    # 1.list posts of friends(to whom we Following)
    pfs = Myprofile.objects.get(user=request.user)
    users = [user for user in pfs.friends.all()]
    myposts = []
    qs = None
    for u in users:
        p = Myprofile.objects.get(user=u)
        p_posts = p.mypost_set.all()
        myposts.append(p_posts)
    # own posts
    m_posts = Mypost.objects.filter(uploaded_by=pfs)
    myposts.append(m_posts)
    if len(myposts) > 0:
        qs = sorted(chain(*myposts), reverse=True, key=lambda obj: obj.cr_date)

    # notifications:
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    # comment
    us = Myprofile.objects.get(user=request.user)
    comment_form = CommentForm()
    if request.method == 'POST':
        comment_form = CommentForm(request.POST or None)
        if comment_form.is_valid():
            post_id = request.POST.get('mypost_pk')
            instance = comment_form.save(commit=False)
            instance.commented_by = us
            instance.post = Mypost.objects.get(id=post_id)
            instance.save()
            comment_form.save()

    context = {
        'myprofiles': myprofiles,
        'story_form': story_form,
        'rel_receiver': rel_receiver,
        'rel_sender': rel_sender,
        'myposts': qs,
        'notifications': results,
        'notifications_count': notifications_count,
        'pfs': pfs,
        'comment_form': comment_form,
    }
    return render(request, 'accounts/photo_home.html', context)


@login_required(login_url='login')
def upload(request):
    vid_form = MypostvideoForm()
    profile = Myprofile.objects.get(user=request.user)
    if request.method == 'POST':
        vid_form = MypostvideoForm(request.POST or None, request.FILES or None)
        if vid_form.is_valid():
            instance = vid_form.save(commit=False)
            instance.uploaded_by = profile
            instance.save()
            vid_form.save()

    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    context = {'profile': profile, 'vid_form': vid_form,
               'notifications': results,
               'notifications_count': notifications_count, }
    return render(request, 'accounts/photo_upload.html', context)


@login_required(login_url='login')
def stories(request):
    # lsit stories
    stry = Story.objects.filter(uploaded_by=request.user.myprofile)
    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    #list stories of friends(to whom we Following)
    pfs = Myprofile.objects.get(user=request.user)
    users = [user for user in pfs.friends.all()]
    stori = []
    qs = None
    for u in users:
        p = Myprofile.objects.get(user=u)
        p_posts = p.story_set.all()
        stori.append(p_posts)

    if len(stori) > 0:
        qs = sorted(chain(*stori), reverse=True, key=lambda obj: obj.cr_date)

    context = {'notifications': results,
               'notifications_count': notifications_count,
               'stry':stry,
               'stori': qs}
    return render(request, 'accounts/photo_stories.html', context)


@login_required(login_url='login')
def chat(request):

    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    context = {'notifications': results,
               'notifications_count': notifications_count, }
    return render(request, 'accounts/photo_chat.html', context)


@login_required(login_url='login')
def profile(request):
    #  post count
    myposts = Mypost.objects.filter(uploaded_by=request.user.myprofile)
    mypostscount = myposts.count

# form
    myprofile = request.user.myprofile
    introvid_form = IntrovidForm(instance=myprofile)

    if request.method == 'POST':
        introvid_form = IntrovidForm(
            request.POST, request.FILES, instance=myprofile)
        if introvid_form.is_valid():
            introvid_form.save()
# lsit stories
    stry = Story.objects.filter(uploaded_by=request.user.myprofile)

# notifications:sad
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

# no of people we follow:
    follow_no = FollowUser.objects.filter(
        sender=pfs, status='accepted').count()

# no of people who follow us:
    following_no = FollowUser.objects.filter(
        receiver=pfs, status='accepted').count()

    context = {'myposts': myposts, 'mypostscount': mypostscount, 'introvid_form': introvid_form, 'stry': stry,
               'notifications': results,
               'notifications_count': notifications_count,
               'follow_no': follow_no,
               'following_no': following_no,
               }
    return render(request, 'accounts/photo_profile.html', context)


@login_required(login_url='login')
def account_setting(request):
    myprofile = request.user.myprofile
    form = MyprofileForm(instance=myprofile)

    if request.method == 'POST':
        form = MyprofileForm(request.POST, request.FILES, instance=myprofile)
        if form.is_valid():
            form.save()

# notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    context = {'form': form,
               'notifications': results,
               'notifications_count': notifications_count,
               }
    return render(request, 'accounts/account_setting.html', context)


@login_required(login_url='login')
def editprofile(request):
    # count
    myposts = Mypost.objects.filter(uploaded_by=request.user.myprofile)
    mypostscount = myposts.count
    # /count

    myprofile = request.user.myprofile
    pic_form = MyprofilepicForm(instance=myprofile)

    if request.method == 'POST':
        pic_form = MyprofilepicForm(
            request.POST, request.FILES, instance=myprofile)
        if pic_form.is_valid():
            pic_form.save()

    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    # no of people we follow:
    follow_no = FollowUser.objects.filter(
        sender=pfs, status='accepted').count()

    # no of people who follow us:
    following_no = FollowUser.objects.filter(
        receiver=pfs, status='accepted').count()

    context = {'pic_form': pic_form, 'mypostscount': mypostscount, 'myposts': myposts,
               'notifications': results,
               'notifications_count': notifications_count,
               'follow_no': follow_no,
               'following_no': following_no,
               }
    return render(request, 'accounts/photo_editprofile.html', context)


@login_required(login_url='login')
def profile_checkout(request, pk):
    myprofile = Myprofile.objects.get(id=pk)
    # no of posts
    posts = Mypost.objects.filter(uploaded_by=myprofile)
    no_posts = posts.count()

    # no of followers
    followers = FollowUser.objects.filter(
                                          Q(receiver = myprofile)
                                          )
    numbers = followers.count()

    # no of following
    following_by_me = FollowUser.objects.filter(
                                          Q(sender = myprofile)
                                          )
    following = following_by_me.count()



    # following func.
    user = User.objects.get(username__iexact=request.user)
    profile = Myprofile.objects.get(user=user)
    rel_r = FollowUser.objects.filter(sender=profile)
    rel_s = FollowUser.objects.filter(receiver=profile)
    rel_receiver = []
    rel_sender = []
    for item in rel_r:
        rel_receiver.append(item.receiver.user)
    for item in rel_s:
        rel_receiver.append(item.sender.user)

    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    context = {'myprofile': myprofile,
               'posts': posts,
               'no_posts': no_posts, 
               'rel_receiver': rel_receiver, 
               'rel_sender': rel_sender,
               'notifications': results,
               'notifications_count': notifications_count,
               'numbers':numbers,
               'following':following }
    return render(request, 'accounts/profile_checkout.html', context)


@login_required(login_url='login')
def search(request):
    # listing prifoles
    me = request.user
    list_profile = Myprofile.objects.all().exclude(user=me)

    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    is_empty = False
    if len(results) == 0:
        is_empty = True

    # search Logic with follow and unfollow funcionality
    if request.method == 'POST':
        srch = request.POST['srh']
        if srch:
            profiles = Myprofile.objects.filter(
                Q(name__icontains=srch)
            ).exclude(user=me)
            if profiles:
                user = User.objects.get(username__iexact=request.user)
                profile = Myprofile.objects.get(user=user)
                rel_r = FollowUser.objects.filter(sender=profile)
                rel_s = FollowUser.objects.filter(receiver=profile)
                rel_receiver = []
                rel_sender = []
                for item in rel_r:
                    rel_receiver.append(item.receiver.user)
                for item in rel_s:
                    rel_receiver.append(item.sender.user)

                context = {'profiles': profiles, 'rel_receiver': rel_receiver, 'rel_sender': rel_sender,
                           'notifications': results,
                           'notifications_count': notifications_count, }
                return render(request, 'accounts/search.html', context)
            else:
                messages.error(request, 'User not found!')
        else:
            return HttpResponseRedirect('/home')

    context = {'list_profile': list_profile, }
    return render(request, 'accounts/search.html', context)

# class based view


class exploreView(ListView):
    model = Myprofile
    template_name = 'accounts/explore.html'
    context_object_name = 'myprofiles'

    def get_queryset(self):
        myprofiles = Myprofile.objects.all().exclude(user=self.request.user)
        return myprofiles

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = User.objects.get(username__iexact=self.request.user)
        profile = Myprofile.objects.get(user=user)
        rel_r = FollowUser.objects.filter(sender=profile)
        rel_s = FollowUser.objects.filter(receiver=profile)
        rel_receiver = []
        rel_sender = []
        for item in rel_r:
            rel_receiver.append(item.receiver.user)
        for item in rel_s:
            rel_receiver.append(item.sender.user)

        context["rel_receiver"] = rel_receiver
        context["rel_sender"] = rel_sender
        context['is_empty'] = False
        if len(self.get_queryset()) == 0:
            context['is_empty'] = True
        return context


@login_required(login_url='login')
def notifications(request):
    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    notifications_time = notifications.dates
    is_empty = False
    if len(results) == 0:
        is_empty = True
    context = {'notifications': results,
               'notifications_count': notifications_count
               }
    return render(request, 'accounts/photo_notifications.html', context)


def send_friend_req(request):
    if request.method == 'POST':
        pk = request.POST.get('myprofile_pk')
        user = request.user
        sender = Myprofile.objects.get(user=user)
        receiver = Myprofile.objects.get(pk=pk)

        rel = FollowUser.objects.create(
            sender=sender, receiver=receiver, status='send')

        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    return redirect('explore')


def del_friend_req(request):
    if request.method == 'POST':
        pk = request.POST.get('myprofile_pk')
        user = request.user
        sender = Myprofile.objects.get(user=user)
        receiver = Myprofile.objects.get(pk=pk)

        rel = FollowUser.objects.get((Q(sender=sender) & Q(receiver=receiver)) |
                                     (Q(sender=receiver) & Q(receiver=sender))
                                     )
        rel.delete()

        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    return redirect('explore')


def accept_invatation(request):
    if request.method == 'POST':
        pk = request.POST.get('myprofile_pk')
        user = request.user
        sender = Myprofile.objects.get(pk=pk)
        receiver = Myprofile.objects.get(user=user)
        rel = get_object_or_404(FollowUser, sender=sender, receiver=receiver)
        if rel.status == 'send':
            rel.status = 'accepted'
            rel.save()

        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    return redirect('notifications')


@login_required(login_url='login')
def reject_invitation(request):
    if request.method == 'POST':
        pk = request.POST.get('myprofile_pk')
        sender = Myprofile.objects.get(pk=pk)
        receiver = Myprofile.objects.get(user=request.user)
        rel = get_object_or_404(FollowUser, sender=sender, receiver=receiver)
        rel.delete()

    return render(request, 'accounts/photo_notifications.html')


@login_required(login_url='login')
def like_unlike_post(request):
    user = request.user
    if request.method == 'POST':
        post_id = request.POST.get('mypost_pk')
        mypost = Mypost.objects.get(id=post_id)
        profile = Myprofile.objects.get(user=user)

        if profile in mypost.liked.all():
            mypost.liked.remove(profile)
        else:
            mypost.liked.add(profile)

        like, created = Like.objects.get_or_create(
            liked_by=profile, post_id=post_id)

        if not created:
            if Like.value == 'like':
                like.delete()
            else:
                Like.value = 'like'
        else:
            like.value = 'Like'

            mypost.save()
            like.save()

        return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    return redirect('home')


def my_post_delet(request):
    user = request.user
    if request.method == 'POST':
        post_id = request.POST.get('mypost_pk')
        mypost = Mypost.objects.get(id=post_id)
        myprofile = Myprofile.objects.get(user=user)
        mypost.delete()
    return redirect('editprofile')


def followers(request):
    # notifications:
    pfs = Myprofile.objects.get(user=request.user)
    notifications = FollowUser.objects.invitations_received(pfs)
    results = list(map(lambda x: x.sender, notifications))
    notifications_count = notifications.count
    notifications_time = notifications.dates
    is_empty = False
    if len(results) == 0:
        is_empty = True

    users = [user for user in pfs.friends.all()]

    context = {'notifications': results,
               'notifications_count': notifications_count
               }
    return render(request, 'accounts/photo_followers.html', context)
